insert into order_item (id,product_code, product_name, quantity,order_id) VALUES
(1,'Mani','Singapore',100.00,1);
