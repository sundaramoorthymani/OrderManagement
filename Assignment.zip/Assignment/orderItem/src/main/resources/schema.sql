CREATE TABLE IF NOT EXISTS order_item (
  id INTEGER  PRIMARY KEY AUTO_INCREMENT,
  product_code VARCHAR(250) NOT NULL,
  product_name VARCHAR(750),
  Quantity DECIMAL(10,2),
  order_id INTEGER
);