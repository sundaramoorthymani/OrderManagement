package com.mani.orderItem.controller;



import com.mani.orderItem.dto.OrderItemDto;
import com.mani.orderItem.model.OrderItem;
import com.mani.orderItem.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
public class OrderItemController {

    @Autowired
    OrderItemService orderService;

    @RequestMapping(value = "/retrieve/order_item/{id}", method = RequestMethod.GET)
    public OrderItemDto findAllCodes(@PathVariable Long id) {

        return orderService.retrieveOrder(id);
    }

    @RequestMapping(value = "/save/order_item", method = RequestMethod.POST)
    public Long saveOrder(@RequestBody OrderItemDto orderItemDto
    ) {

        return orderService.createOrder(orderItemDto);
    }
}
