package com.mani.orderItem.service;


import com.mani.orderItem.dto.OrderItemDto;
import com.mani.orderItem.model.OrderItem;

import java.util.List;

/**
 * Created by Sundar on 19/09/2020.
 */

public interface OrderItemService {
    OrderItemDto retrieveOrder(Long id);
    Long createOrder(OrderItemDto order);
}
