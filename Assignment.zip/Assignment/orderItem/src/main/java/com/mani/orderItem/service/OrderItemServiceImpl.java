package com.mani.orderItem.service;


import com.mani.orderItem.dto.OrderItemDto;
import com.mani.orderItem.model.OrderItem;
import com.mani.orderItem.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Sundar on 19/09/2020.
 */
@Service
public class OrderItemServiceImpl implements OrderItemService {

    @Autowired
    private OrderItemRepository orderTblRepository;

    @Override
    public OrderItemDto retrieveOrder(Long id) {
        OrderItem orderItem= orderTblRepository.findById(id).get();
        OrderItemDto orderItemDto= new OrderItemDto();
        orderItemDto.setProductName(orderItem.getProductName());
        orderItemDto.setOrderId(orderItem.getOrderId());
        orderItemDto.setQuantity(orderItem.getQuantity());
        orderItemDto.setProductCode(orderItem.getProductCode());
        orderItemDto.setId(orderItem.getId());

        return orderItemDto;
    }

    @Override
    public Long createOrder(OrderItemDto orderItemDto) {
        OrderItem orderItem = new OrderItem();
        orderItem.setProductName(orderItemDto.productName);
        orderItem.setProductCode(orderItemDto.productCode);
        orderItem.setOrderId(orderItemDto.orderId);
        orderItem.setQuantity(orderItemDto.quantity);
        OrderItem orderItem1 =orderTblRepository.save(orderItem);
        return orderItem1.getId();
    }
}
