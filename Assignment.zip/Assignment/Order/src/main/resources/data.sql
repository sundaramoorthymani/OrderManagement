insert into Order_tbl (id,customer_name, shipping_address, order_date, total, order_item_id) VALUES
(1,'Mani','Singapore', CURRENT_DATE(),100.00, 1);
