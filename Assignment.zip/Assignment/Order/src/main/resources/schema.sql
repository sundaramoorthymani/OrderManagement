CREATE TABLE IF NOT EXISTS Order_tbl (
  id INTEGER  PRIMARY KEY AUTO_INCREMENT,
  customer_name VARCHAR(250) NOT NULL,
  shipping_address VARCHAR(750),
  order_date DATE,
  total DECIMAL(10,2),
  order_item_id INTEGER
);