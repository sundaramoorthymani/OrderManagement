package com.mani.order.Order.service;

import com.mani.order.Order.dto.Order;
import com.mani.order.Order.error.OrderNotFound;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Sundar on 19/09/2020.
 */

public interface OrderService {
    Order retrieveOrder(Long id) throws OrderNotFound;
    Long createOrder(Order order);
}
