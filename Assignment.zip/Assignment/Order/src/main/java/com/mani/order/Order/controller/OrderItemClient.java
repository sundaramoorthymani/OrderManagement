package com.mani.order.Order.controller;

import com.mani.order.Order.dto.OrderItemDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by Sundar on 20/09/2020.
 */
@FeignClient(name = "orderItemService", url = "http://localhost:8091")
public interface OrderItemClient {

    @GetMapping("/orderItemService/retrieve/order_item/{id}")
    public OrderItemDto getOrderItems(@PathVariable(value="id") Long id);

    @RequestMapping(value = "/orderItemService/save/order_item", method = RequestMethod.POST)
    public Long saveOrder(@RequestBody OrderItemDto orderItemDto);

}
