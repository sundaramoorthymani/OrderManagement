package com.mani.order.Order.error;

/**
 * Created by Sundar on 20/09/2020.
 */
public class OrderNotFound extends Exception {
    public OrderNotFound(String s){
        super(s);
    }
}
