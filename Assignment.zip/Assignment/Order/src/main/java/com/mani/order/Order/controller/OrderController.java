package com.mani.order.Order.controller;


import com.mani.order.Order.dto.Order;
import com.mani.order.Order.dto.OrderItemDto;
import com.mani.order.Order.error.OrderNotFound;
import com.mani.order.Order.repository.OrderTblRepository;
import com.mani.order.Order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**spring.datasource.url = jdbc:h2:file:C:/data/sample
 * Created by Sundar on 19/09/2020.
 */

@RestController
public class OrderController {

    @Autowired
    OrderService orderService;

    @RequestMapping(value = "/retrieve/order/{id}", method = RequestMethod.GET)
    public Order findAllCodes(@PathVariable Long id) throws OrderNotFound {
        return orderService.retrieveOrder(id);
    }

    @RequestMapping(value = "/save/order", method = RequestMethod.POST)
    public String  saveOrder(@RequestBody Order order) {

        Long id=  orderService.createOrder(order);
        return "Order Placed: id:"+id;
    }
}
