package com.mani.order.Order.service;

import com.mani.order.Order.controller.OrderItemClient;
import com.mani.order.Order.dto.Order;
import com.mani.order.Order.dto.OrderItemDto;
import com.mani.order.Order.error.OrderNotFound;
import com.mani.order.Order.model.OrderTbl;
import com.mani.order.Order.repository.OrderTblRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Sundar on 19/09/2020.
 */
@Service
public class OrderServiceImpl  implements OrderService {

    @Autowired
    private OrderTblRepository orderTblRepository;
    @Autowired
    OrderItemClient orderItemClient;

    @Override
    public Order retrieveOrder(Long id) throws OrderNotFound {
        List<Order> orders=new ArrayList<>();


        OrderTbl s = orderTblRepository.findById(id).get();
        if(s==null){
            throw new OrderNotFound("Sorry Order Notfound");
        }
        OrderItemDto orderItemDto = orderItemClient.getOrderItems(s.getOrderItemId());

            Order order=new Order();
            order.setId(s.getId());
            order.setCustomerName(s.customerName);
            order.setOrderDate(s.orderDate);
            order.setShippingAddress(s.shippingAddress);
            order.setTotal(s.getTotal());
        order.setOrderItemDto(orderItemDto);
        return order;
    }

    @Override
    public Long createOrder(Order orderS) {
        OrderTbl order=new OrderTbl();
        order.setCustomerName(orderS.getCustomerName());
        order.setOrderDate(new Date());
        order.setShippingAddress(orderS.getShippingAddress());
        order.setTotal(orderS.getTotal());
        Long orderItemId = orderItemClient.saveOrder(orderS.getOrderItemDto());
        order.setOrderItemId(orderItemId);
        order =orderTblRepository.save(order);
        return order.getId();
    }
}
