package com.mani.order.Order.model;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by Parani on 19/09/2020.
 */
@Entity
@Table(name = "order_tbl")
public class OrderTbl {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long id;
    public String customerName;
    public Date orderDate;
    public String shippingAddress;
    public Double total;
    public Long orderItemId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Long getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(Long orderItemId) {
        this.orderItemId = orderItemId;
    }
}
