package com.mani.order.Order.repository;

import com.mani.order.Order.model.OrderTbl;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Sundar on 19/09/2020.
 */
@Repository
public interface OrderTblRepository extends JpaRepository<OrderTbl, Long> {
}
